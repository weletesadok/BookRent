-- AlterTable
ALTER TABLE "Book" ADD COLUMN     "rating" INTEGER DEFAULT 0;
