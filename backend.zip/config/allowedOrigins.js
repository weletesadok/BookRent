const allowedOrigins = ["http://localhost:5173"];
module.exports = allowedOrigins;
